#define UTIL_LINUX_VERSION "2.11q"
#define util_linux_version "util-linux-2.11q"

#define HAVE_scsi_h
#define HAVE_blkpg_h
#define HAVE_kd_h
#define HAVE_locale_h
#define HAVE_langinfo_h
#define HAVE_sys_user_h
#define HAVE_rpcsvc_nfs_prot_h
#define HAVE_asm_types_h
#define HAVE_inet_aton
#define HAVE_fsync
#define HAVE_getdomainname
#define HAVE_nanosleep
#define HAVE_personality
#define HAVE_updwtmp
#define HAVE_libintl_h
#define ENABLE_NLS
#define HAVE_progname
#define HAVE_openpty
#define ENABLE_WIDECHAR
#define HAVE_tm_gmtoff
